#ifndef FTS_LIBRARY_H
#define FTS_LIBRARY_H

void fts_library_init(void);
void fts_library_deinit(void);

#endif
