/* Copyright (c) 2015-2018 Dovecot authors, see the included COPYING file */

#ifndef PUSH_NOTIFICATION_EVENT_MESSAGETRASH_H
#define PUSH_NOTIFICATION_EVENT_MESSAGETRASH_H


struct push_notification_event_messagetrash_data {
    /* Can only be true. */
    bool trash;
};


#endif /* PUSH_NOTIFICATION_EVENT_MESSAGETRASH_H */

