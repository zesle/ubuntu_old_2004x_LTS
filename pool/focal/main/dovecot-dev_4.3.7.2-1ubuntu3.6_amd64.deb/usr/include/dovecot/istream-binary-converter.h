#ifndef ISTREAM_BINARY_CONVERTER_H
#define ISTREAM_BINARY_CONVERTER_H

struct istream *i_stream_create_binary_converter(struct istream *input);

#endif
