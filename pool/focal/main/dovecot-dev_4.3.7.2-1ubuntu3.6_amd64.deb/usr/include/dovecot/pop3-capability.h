#ifndef POP3_CAPABILITY_H
#define POP3_CAPABILITY_H

#define POP3_CAPABILITY_REPLY \
	"CAPA\r\n" \
	"TOP\r\n" \
	"UIDL\r\n" \
	"RESP-CODES\r\n" \
	"PIPELINING\r\n" \
	"AUTH-RESP-CODE\r\n"

/* + SASL */

#endif
